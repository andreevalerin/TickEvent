<?php

namespace App\Http\Controllers\Organizador;

use App\Http\Controllers\Controller;
use App\Models\Evento;
use App\Models\Entrada;
use App\Models\Pago;
use App\Models\Tarifa;
use App\Models\Zona;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class EventoController extends Controller
{
    public function index(Request $request)
    {
        $eventos = Evento::where('organizador_id', $request->user()->id)
            ->withCount('zonas')
            ->orderByDesc('fecha_evento')
            ->get();

        $eventoIds = $eventos->pluck('id');
        $entradasPorEvento = Entrada::query()
            ->join('reservas', 'reservas.id', '=', 'entradas.reserva_id')
            ->join('pagos', 'pagos.reserva_id', '=', 'reservas.id')
            ->where('pagos.estado', 'aprobado')
            ->whereIn('reservas.evento_id', $eventoIds)
            ->select('reservas.evento_id', DB::raw('COUNT(entradas.id) as total'))
            ->groupBy('reservas.evento_id')
            ->pluck('total', 'evento_id');
        $ingresosPorEvento = Pago::query()
            ->join('reservas', 'reservas.id', '=', 'pagos.reserva_id')
            ->where('pagos.estado', 'aprobado')
            ->whereIn('reservas.evento_id', $eventoIds)
            ->select('reservas.evento_id', DB::raw('SUM(pagos.monto_centimos) as total'))
            ->groupBy('reservas.evento_id')
            ->pluck('total', 'evento_id');

        $eventos->each(function ($evento) use ($entradasPorEvento, $ingresosPorEvento) {
            $evento->entradas_vendidas = (int) ($entradasPorEvento[$evento->id] ?? 0);
            $evento->ingresos_centimos = (int) ($ingresosPorEvento[$evento->id] ?? 0);
        });

        $metricas = [
            'eventos' => $eventos->count(),
            'proximos' => $eventos->where('estado', 'publicado')->where('fecha_evento', '>=', now())->count(),
            'entradas' => $eventos->sum('entradas_vendidas'),
            'ingresos_centimos' => $eventos->sum('ingresos_centimos'),
        ];

        $conteos = [
            'todos' => $eventos->count(),
            'proximos' => $eventos->where('estado', 'publicado')->where('fecha_evento', '>=', now())->count(),
            'pasados' => $eventos->where('fecha_evento', '<', now())->count(),
            'borradores' => $eventos->where('estado', 'borrador')->count(),
        ];
        $filtro = in_array($request->input('filtro'), ['proximos', 'pasados', 'borradores'], true)
            ? $request->input('filtro')
            : 'todos';
        $orden = in_array($request->input('orden'), ['recientes', 'antiguos', 'titulo'], true)
            ? $request->input('orden')
            : 'recientes';
        $busqueda = trim($request->string('q')->toString());
        $filtrados = $eventos
            ->when($filtro === 'proximos', fn ($coleccion) => $coleccion->where('estado', 'publicado')->where('fecha_evento', '>=', now()))
            ->when($filtro === 'pasados', fn ($coleccion) => $coleccion->where('fecha_evento', '<', now()))
            ->when($filtro === 'borradores', fn ($coleccion) => $coleccion->where('estado', 'borrador'))
            ->when($busqueda !== '', function ($coleccion) use ($busqueda) {
                $texto = mb_strtolower($busqueda);

                return $coleccion->filter(fn ($evento) => str_contains(mb_strtolower($evento->titulo), $texto)
                    || str_contains(mb_strtolower($evento->lugar), $texto)
                    || str_contains(mb_strtolower($evento->ciudad), $texto));
            });
        $filtrados = (match ($orden) {
            'antiguos' => $filtrados->sortBy('fecha_evento'),
            'titulo' => $filtrados->sortBy('titulo', SORT_NATURAL | SORT_FLAG_CASE),
            default => $filtrados->sortByDesc('fecha_evento'),
        })->values();
        $pagina = max(1, (int) $request->input('page', 1));
        $eventos = new LengthAwarePaginator(
            $filtrados->forPage($pagina, 6)->values(),
            $filtrados->count(),
            6,
            $pagina,
            ['path' => $request->url(), 'query' => $request->query()]
        );

        return view('organizador.eventos.index', compact('eventos', 'metricas', 'conteos', 'filtro', 'orden', 'busqueda'));
    }

    public function create()
    {
        return view('organizador.eventos.form', [
            'evento' => new Evento(),
            'zonasFormulario' => [],
        ]);
    }

    public function store(Request $request)
    {
        $datos = $this->validarDatos($request);
        $imagenes = $this->guardarImagenes($request);

        $evento = DB::transaction(function () use ($request, $datos, $imagenes) {
            $evento = Evento::create([
                'organizador_id' => $request->user()->id,
                'titulo' => $datos['titulo'],
                'slug' => $this->generarSlug($datos['titulo']),
                'categoria' => $datos['categoria'],
                'descripcion' => $datos['descripcion'] ?? null,
                'fecha_evento' => $datos['fecha_evento'],
                'lugar' => $datos['lugar'],
                'direccion' => $datos['direccion'] ?? null,
                'ciudad' => $datos['ciudad'],
                'aforo_total' => 1,
                'imagen_principal' => $imagenes['imagen_principal'] ?? null,
                'imagen_plano' => $imagenes['imagen_plano'] ?? null,
                'estado' => $datos['estado'],
            ]);

            $this->sincronizarZonas($evento, $datos['zonas']);

            return $evento;
        }, 3);

        return redirect()
            ->route('organizador.eventos.index')
            ->with('estado', 'Evento creado correctamente.');
    }

    public function edit(Request $request, Evento $evento)
    {
        $this->autorizarPropietario($request, $evento);
        abort_if($evento->estado === 'retirado', 403);
        $evento->load(['zonas' => function ($consulta) {
            $consulta->with('tarifas')->orderBy('id');
        }]);
        $zonasFormulario = $evento->zonas->map(function ($zona) {
            return [
                'id' => $zona->id,
                'nombre' => $zona->nombre,
                'capacidad' => $zona->capacidad,
                'activo' => $zona->activo,
                'tarifas' => $zona->tarifas->map(function ($tarifa) {
                    return [
                        'id' => $tarifa->id,
                        'nombre' => $tarifa->nombre,
                        'precio' => $tarifa->precio,
                        'activo' => $tarifa->activo,
                    ];
                })->values()->all(),
            ];
        })->values()->all();

        return view('organizador.eventos.form', compact('evento', 'zonasFormulario'));
    }

    public function update(Request $request, Evento $evento)
    {
        $this->autorizarPropietario($request, $evento);
        abort_if($evento->estado === 'retirado', 403);
        $datos = $this->validarDatos($request);
        $imagenes = $this->guardarImagenes($request);

        DB::transaction(function () use ($evento, $datos, $imagenes) {
            $eventoBloqueado = Evento::whereKey($evento->id)
                ->lockForUpdate()
                ->firstOrFail();
            $eventoBloqueado->update([
                'titulo' => $datos['titulo'],
                'categoria' => $datos['categoria'],
                'descripcion' => $datos['descripcion'] ?? null,
                'fecha_evento' => $datos['fecha_evento'],
                'lugar' => $datos['lugar'],
                'direccion' => $datos['direccion'] ?? null,
                'ciudad' => $datos['ciudad'],
                'imagen_principal' => $imagenes['imagen_principal']
                    ?? $eventoBloqueado->imagen_principal,
                'imagen_plano' => $imagenes['imagen_plano']
                    ?? $eventoBloqueado->imagen_plano,
                'estado' => $datos['estado'],
            ]);

            $this->sincronizarZonas($eventoBloqueado, $datos['zonas']);
        }, 3);

        return redirect()
            ->route('organizador.eventos.index')
            ->with('estado', 'Evento actualizado correctamente.');
    }

    public function destroy(Request $request, Evento $evento)
    {
        $this->autorizarPropietario($request, $evento);

        DB::transaction(function () use ($evento) {
            $eventoBloqueado = Evento::whereKey($evento->id)
                ->lockForUpdate()
                ->firstOrFail();
            $eventoBloqueado->update(['estado' => 'retirado']);
            $zonaIds = $eventoBloqueado->zonas()->pluck('id');
            Zona::whereIn('id', $zonaIds)->update(['activo' => false]);
            Tarifa::whereIn('zona_id', $zonaIds)->update(['activo' => false]);
        }, 3);

        return redirect()
            ->route('organizador.eventos.index')
            ->with('estado', 'Evento retirado de la venta.');
    }

    private function validarDatos(Request $request): array
    {
        $datos = $request->validate([
            'titulo' => ['required', 'string', 'max:150'],
            'categoria' => ['required', 'in:concierto,partido'],
            'descripcion' => ['nullable', 'string', 'max:3000'],
            'fecha_evento' => ['required', 'date'],
            'lugar' => ['required', 'string', 'max:150'],
            'direccion' => ['nullable', 'string', 'max:180'],
            'ciudad' => ['required', 'string', 'max:80'],
            'estado' => ['required', 'in:borrador,publicado'],
            'imagen_principal' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:5120'],
            'imagen_plano' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:5120'],
            'zonas' => ['required', 'array', 'min:1', 'max:30'],
            'zonas.*.id' => ['nullable', 'integer'],
            'zonas.*.nombre' => ['required', 'string', 'max:60'],
            'zonas.*.capacidad' => ['required', 'integer', 'min:1', 'max:1000000'],
            'zonas.*.activo' => ['nullable', 'boolean'],
            'zonas.*.tarifas' => ['required', 'array', 'min:1', 'max:20'],
            'zonas.*.tarifas.*.id' => ['nullable', 'integer'],
            'zonas.*.tarifas.*.nombre' => ['required', 'string', 'max:60'],
            'zonas.*.tarifas.*.precio' => ['required', 'numeric', 'min:0.01', 'max:99999999.99'],
            'zonas.*.tarifas.*.activo' => ['nullable', 'boolean'],
        ]);

        foreach ($datos['zonas'] as $indice => $zona) {
            $nombres = collect($zona['tarifas'])
                ->pluck('nombre')
                ->map(fn ($nombre) => mb_strtolower(trim($nombre)));

            if ($nombres->duplicates()->isNotEmpty()) {
                throw ValidationException::withMessages([
                    "zonas.$indice.tarifas" => 'No repitas el nombre de una tarifa dentro de la misma zona.',
                ]);
            }

            if ($datos['estado'] === 'publicado' && (bool) ($zona['activo'] ?? false)) {
                $tieneTarifaActiva = collect($zona['tarifas'])
                    ->contains(fn ($tarifa) => (bool) ($tarifa['activo'] ?? false));

                if (!$tieneTarifaActiva) {
                    throw ValidationException::withMessages([
                        "zonas.$indice.tarifas" => 'Cada zona activa debe tener al menos una tarifa activa para publicar el evento.',
                    ]);
                }
            }
        }

        if ($datos['estado'] === 'publicado') {
            $tieneZonaVendible = collect($datos['zonas'])->contains(
                fn ($zona) => (bool) ($zona['activo'] ?? false)
                    && collect($zona['tarifas'])->contains(
                        fn ($tarifa) => (bool) ($tarifa['activo'] ?? false)
                    )
            );

            if (!$tieneZonaVendible) {
                throw ValidationException::withMessages([
                    'zonas' => 'El evento debe tener al menos una zona activa con una tarifa activa para publicarse.',
                ]);
            }
        }

        return $datos;
    }

    private function guardarImagenes(Request $request): array
    {
        $imagenes = [];

        foreach (['imagen_principal', 'imagen_plano'] as $campo) {
            if ($request->hasFile($campo)) {
                $imagenes[$campo] = 'storage/'.$request->file($campo)->store('eventos', 'public');
            }
        }

        return $imagenes;
    }

    private function sincronizarZonas(Evento $evento, array $zonas): void
    {
        $zonaIds = [];
        $aforo = 0;

        foreach ($zonas as $datosZona) {
            if (!empty($datosZona['id'])) {
                $zona = $evento->zonas()
                    ->whereKey($datosZona['id'])
                    ->lockForUpdate()
                    ->firstOrFail();
                $zona->update([
                    'nombre' => $datosZona['nombre'],
                    'capacidad' => $datosZona['capacidad'],
                    'activo' => (bool) ($datosZona['activo'] ?? false),
                ]);
            } else {
                $zona = $evento->zonas()->create([
                    'nombre' => $datosZona['nombre'],
                    'capacidad' => $datosZona['capacidad'],
                    'activo' => (bool) ($datosZona['activo'] ?? true),
                ]);
            }

            $zonaIds[] = $zona->id;
            $aforo += (int) $datosZona['capacidad'];
            $tarifaIds = [];

            foreach ($datosZona['tarifas'] as $datosTarifa) {
                if (!empty($datosTarifa['id'])) {
                    $tarifa = $zona->tarifas()
                        ->whereKey($datosTarifa['id'])
                        ->lockForUpdate()
                        ->firstOrFail();
                    $tarifa->update([
                        'nombre' => $datosTarifa['nombre'],
                        'precio' => $datosTarifa['precio'],
                        'activo' => (bool) ($datosTarifa['activo'] ?? false),
                    ]);
                } else {
                    $tarifa = $zona->tarifas()->create([
                        'nombre' => $datosTarifa['nombre'],
                        'precio' => $datosTarifa['precio'],
                        'activo' => (bool) ($datosTarifa['activo'] ?? true),
                    ]);
                }

                $tarifaIds[] = $tarifa->id;
            }

            $zona->tarifas()->whereNotIn('id', $tarifaIds)->update(['activo' => false]);
        }

        $evento->zonas()->whereNotIn('id', $zonaIds)->update(['activo' => false]);
        $evento->update(['aforo_total' => $aforo]);
    }

    private function generarSlug(string $titulo): string
    {
        $base = Str::slug($titulo) ?: 'evento';
        $slug = $base;
        $numero = 2;

        while (Evento::where('slug', $slug)->exists()) {
            $slug = $base.'-'.$numero;
            $numero++;
        }

        return $slug;
    }

    private function autorizarPropietario(Request $request, Evento $evento): void
    {
        abort_unless(
            (int) $evento->organizador_id === (int) $request->user()->id,
            403
        );
    }
}
