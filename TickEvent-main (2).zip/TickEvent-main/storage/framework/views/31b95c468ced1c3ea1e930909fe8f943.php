
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TicketEvent | Inicio</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: #063b3d;
            color: white;
        }

        header {
            height: 65px;
            padding: 0 6%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: #062d30;
        }

        .logo {
            font-size: 22px;
            font-weight: bold;
            color: white;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin-left: 25px;
            font-size: 14px;
        }

        .registro {
            background: #35d9c5;
            color: #063b3d;
            padding: 12px 20px;
            border-radius: 9px;
        }

        .hero {
            padding: 65px 6%;
            min-height: 300px;
            background: linear-gradient(90deg, #002d30, #063b3d);
        }

        .hero small {
            color: #35d9c5;
        }

        .hero h1 {
            font-size: 48px;
            margin: 18px 0;
        }

        .hero h1 span {
            color: #35d9c5;
        }

        .hero p {
            color: #c4d6d5;
        }

        .buscador {
            background: white;
            color: #234;
            margin: -25px auto 35px;
            width: 88%;
            padding: 18px;
            border-radius: 12px;
            display: flex;
            justify-content: space-between;
            gap: 15px;
        }

        .buscador input {
            flex: 1;
            border: none;
            outline: none;
            font-size: 14px;
        }

        button {
            border: none;
            background: #35d9c5;
            color: #063b3d;
            padding: 13px 28px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
        }

        .cartelera {
            padding: 0 6% 35px;
        }

        .cartelera h2 {
            font-size: 25px;
        }

        .subtitulo {
            color: #a9c4c1;
            margin: 5px 0 20px;
            font-size: 13px;
        }

        .eventos {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 18px;
        }

        .evento {
            background: white;
            color: #153c3e;
            border-radius: 12px;
            overflow: hidden;
        }

        .evento img {
            width: 100%;
            height: 135px;
            object-fit: cover;
        }

        .info {
            padding: 15px;
        }

        .fecha {
            font-size: 11px;
            color: #668080;
        }

        .info h3 {
            margin: 8px 0;
            font-size: 17px;
        }

        .precio {
            margin: 15px 0;
            font-weight: bold;
            font-size: 20px;
        }

        .evento button {
            width: 100%;
        }

        .beneficios {
            background: #10494a;
            padding: 25px 6%;
            display: flex;
            justify-content: space-between;
            gap: 20px;
        }

        .beneficio h4 {
            margin-bottom: 8px;
        }

        .beneficio p {
            color: #b4d0ce;
            font-size: 12px;
        }

        @media (max-width: 850px) {
            .eventos {
                grid-template-columns: repeat(2, 1fr);
            }

            .hero h1 {
                font-size: 36px;
            }
        }

        @media (max-width: 550px) {
            nav a {
                margin-left: 8px;
                font-size: 11px;
            }

            .buscador, .beneficios {
                flex-direction: column;
            }

            .eventos {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>

    <header>
        <div class="logo">🎟 TICKEVENT</div>

        <nav>
            <a href="#">Contáctanos</a>
            <a href="#">Iniciar sesión</a>
            <a href="#" class="registro">Registrarse</a>
        </nav>
    </header>

    <section class="hero">
        <small>MÚSICA, PASIÓN Y MOMENTOS EN VIVO</small>

        <h1>Tu próxima entrada<br>está <span>aquí</span></h1>

        <p>Conciertos y partidos en Perú. Elige tu próximo gran momento.</p>
    </section>

    <section class="buscador">
        <input type="text" placeholder="¿Qué quieres vivir? Busca un artista, equipo o evento">
        <input type="text" placeholder="Categoría: Todos los eventos">
        <button>⌕ Buscar</button>
    </section>

    <section class="cartelera">
        <h2>Cartelera</h2>
        <p class="subtitulo">Tu lugar está en los mejores momentos. Encuentra el tuyo.</p>

        <div class="eventos">

            <div class="evento">
                <img src="https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=600" alt="Concierto">
                <div class="info">
                    <span class="fecha">14 NOV 2026</span>
                    <h3>Una noche de indie</h3>
                    <p class="fecha">Costa 21 - San Miguel, Lima</p>
                    <div class="precio">S/ 120</div>
                    <button>Ver entradas</button>
                </div>
            </div>

            <div class="evento">
                <img src="https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=600" alt="Fútbol">
                <div class="info">
                    <span class="fecha">15 NOV 2026</span>
                    <h3>Alianza Lima vs. Melgar</h3>
                    <p class="fecha">Estadio Alejandro Villanueva</p>
                    <div class="precio">S/ 45</div>
                    <button>Ver entradas</button>
                </div>
            </div>

            <div class="evento">
                <img src="https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=600" alt="Concierto">
                <div class="info">
                    <span class="fecha">21 NOV 2026</span>
                    <h3>Lima suena en vivo</h3>
                    <p class="fecha">Anfiteatro del Parque de la Exposición</p>
                    <div class="precio">S/ 85</div>
                    <button>Ver entradas</button>
                </div>
            </div>

            <div class="evento">
                <img src="https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=600" alt="Fútbol">
                <div class="info">
                    <span class="fecha">22 NOV 2026</span>
                    <h3>Sporting Cristal vs. Grau</h3>
                    <p class="fecha">Estadio Alberto Gallardo</p>
                    <div class="precio">S/ 35</div>
                    <button>Ver entradas</button>
                </div>
            </div>

        </div>
    </section>

    <section class="beneficios">
        <div class="beneficio">
            <h4>Paga a tu manera</h4>
            <p>Con tarjeta, Yape o Plin. Tú eliges.</p>
        </div>

        <div class="beneficio">
            <h4>Tu QR al instante</h4>
            <p>Recibe tus entradas directo en tu correo.</p>
        </div>

        <div class="beneficio">
            <h4>Compra con tranquilidad</h4>
            <p>Pago seguro y tus datos siempre protegidos.</p>
        </div>
    </section>

</body>
</html>
<?php /**PATH C:\TickEvent-main\resources\views/interfaztickevent.blade.php ENDPATH**/ ?>